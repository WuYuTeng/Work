﻿package com.alipay.config;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id = "2016091500517047";
	
	// 商户私钥，您的PKCS8格式RSA2私钥
    public static String merchant_private_key = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDq3Jr9aXcHyI6qsCMZQttjhi/eZXxTyKb3fQnTR4GGxHLUQXDFZDD68zOLTYaOb01CJDvJ/SxPNYbWcAzN5aO8TAIY9fFrHl1+ScWzXdQXY05a5B0XZDmBbXV6cYzMD2GbZkZW75n83f8DiNW0JuO8vc6Da3gK9b6QmCBNjAN/sRU945CLPQsynyrBZufXWPjh3BEFB3/wd/+2Tyc3PUiTYwy6vWh/FEic3y7zo6tYG+EaBzEbkZB7WeYsTC0DHG1RjGsQjU0Bu8fUdTFnrFySWr7b0RMezSnGZICpTNj6qH2sb+Pdxv1JDKpntu092sIMkWy9Ss9jP3u9zFxzUJxnAgMBAAECggEAcjjCBBbDtfxbLjYli8aRLjD3nOCce57tXRXprmBrZSCrfAErmERm8dVPryMQGruUxmMa1NyVLRyqLCYohAZ4AD6zEnKia+dDrwSv6tDqMkmwtNGWOGcc9I5IgTkyMZgVb19pPCShLnLE8HIfBNOZFJT3F8Evi50Chg4GP9ClbvbBCu13YZJaOufw4Ofur1CGpheorNs9u4hAMuyq7DG2YNQSHNgYzWyPVtQBHRKgwaiHNlT1cxG3lU3+5VZN4jaWwM0qtGJ7UwRF1JjV6JNrF0eOiw/Q54oU832CQWO39zxQbnjofBqKxBGzwycYGVspM3L3yxsth1710DTFXF2y8QKBgQD3bWPCbU1RcwCUIKb3xQssE6SOFYuKvVUc0YE0DVA8OsXdhvXY0xPVOihABxRvC6Oe6HjmSZakR5l/ChgEsFLX3XoE+HWnRdbJa7+JWXHTGByNeNdTV+/INWTIMM2R3fdtmK00YhqvbHQMO9I+Z7lGfvPUGej885m/zPsRlrMALwKBgQDy/8NDLFb4Cqr/1rWcsMuUWkAI/9qVq6FwT0KS7UvYB7q54Z6qbg6YxVfgYsAqx2U1P1Aks2KqSMxorlu+rxoepIt9yKGrZHZ12BUQJTim9wdsyx8+AMAoPw/h/P/PHb/mfWaqJE1WFudhOgvuxkxBhJo8qiMcr7jGt9e+2VihSQKBgBEl1aod5SPl8n5RnQDC+Tk+y0LFn3woDwQGSQwQeCUUda4asmMqjc9TToLRessPZXGX7vkW1IfiJnM1geChT7yCLvi1N4I2RuKCwy2Ds23L1/6+Bz5Rc97ORIPTTgvz9Df2QtrEidDqlUhbxQBqM9784W0rtogBYgB29leLuDAlAoGBAMnUybhngazwH2v0SFBnQBBujbVr3YBnV+XSz3b+BfrfIKb30TO5ygH2F7FWFErz5wo9FjIFlTPe13kzKRzOj6FYBkxpcm7LOOFUotoQMGft0or4g3CaawCCsIyB+W9sRFILYlR7ZojU6UYGUpb2uavJmdo9boCLK6xSUq5AFK+RAoGBAJa4trO14IturwERNpptK4ImgbO42OV/f3KIGUnxg5a/X7C6rG64thSwqS2UpPHY1i+cTWlstZaSe5MwjnKTxikvZtZYwlPx6SXyxouXvIN69BAGNYPF71m/+Si1GwMNYYo36PtTsRLrCYLq2YgsJZUfu555LAtTS26OHcaW3LkO";
	
	// 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApsH5O0ENQNX3T/plAP7D3o40FWPs9DfvTAfdn9hAgPOxOJVpNGLQnByeVk+AEDon1FvmrHh9UGW4AKV/cUrtS9ldjSmNIFYYu7Cr3P+gEBfjHGoDJu4l2EjQonfFPaBksTEnZzDb1fLxvVF5uSiMNT50sxIk/dBbIMAut3Ltir3IiL2F1YgO3uuyXlCbRW1r1+yY6ivWLDe4KIqdJ9SPixk0s6eEed9TqtkYSFklk28l+iHatuaPPBn30gY/TwyALwd/kZY7CiK03yEDNqesdiPNNtLFtOROls8UJttGteiRQImHUGIWX9mz5XQWvh68At/s1r8/HnjUXFqZTqf+7wIDAQAB";

	// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String notify_url = "http://localhost:8080/alipay.trade.page.pay-JAVA-UTF-8/notify_url.jsp";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String return_url = "http://localhost:8080/alipay.trade.page.pay-JAVA-UTF-8/return_url.jsp";

	// 签名方式
	public static String sign_type = "RSA2";
	
	// 字符编码格式
	public static String charset = "utf-8";
	
	// 支付宝网关
	public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";
	
	// 支付宝网关
	public static String log_path = "C:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /** 
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

